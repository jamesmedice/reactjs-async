bundleRegister().set('./bootstrap/footer.js', function (props){
   var e = React.createElement;
   return e('div', {
	  className: 'Footer' 
   }, 'Footer');
});