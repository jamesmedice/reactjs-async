bundleRegister().set('./login/login.js', function(){
    return React.createElement('h2', { className: 'Login'}, "Access to premium users.");
});