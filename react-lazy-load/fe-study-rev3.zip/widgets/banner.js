widgetRegister().set('./widgets/banner.js', function(){
	var e = React.createElement;
	return e('div', { className: 'Banner' }, 'Async Widget Banner');
});