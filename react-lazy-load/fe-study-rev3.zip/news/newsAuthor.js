bundleRegister().set('./news/newsAuthor.js', function(){
	var e = React.createElement;
	return e('div', {}, 'Written by Frodo');
});