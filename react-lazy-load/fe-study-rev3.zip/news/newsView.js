bundleRegister().set('./news/newsView.js', function(){
	var e = React.createElement;
	return e('div', {}, 
	  e('h3', null, 'You should pay 1 gold coin to access this site.')
	);
});