bundleRegister().set('./news/news.js', function(){
	var e = React.createElement;
	return e('div', {}, 
	  e('h1', null, 'Those are the news:'),
	  e('ol', null, 
	    e('li', null, 
		  e('a', { href: '#news/1'}, 'View first news')
		),
		e('li', null, 
		  e('a', { href: '#news/2'}, 'View 2 news')
		),
		e('li', null, 
		  e('a', { href: '#news/2'}, 'View 3 news')
		)
	  )
	);
});