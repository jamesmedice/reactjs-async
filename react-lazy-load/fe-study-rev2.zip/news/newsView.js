bundleRegister().set('./news/newsView.js', function(){
	var e = React.createElement;
	return e('div', {}, 
	  e('h3', null, 'Chaos in the world', e('a', { href: '#news/2/author'}, 'Author: Batman'))
	);
});