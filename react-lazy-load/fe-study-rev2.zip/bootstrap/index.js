(function (){
	
	var layout = [
	  { file:'lib/dom'},
	  { file: 'bootstrap/footer', css: true},
	  { file:'bootstrap/header', css: true}
	];

	var routes = {
	  '/': {
		 render: 'Index'
	  },
	  '/home': {
		 render: 'Welcome to home page'
	  },
	  '/about': 'About',
	  '/contact': 'React & Routing',
	  '/news': {
		  url: './news/news.js'
	  },
	  '/login': {
		  url: './login/login.js',
		  css: './login/login.css'
	  },
	  '/news/{id}': {
		  url: './news/newsView.js'
	  },
	  '/news/{id}/author': {
		  url: './news/newsAuthor.js'
	  }
	};
	
	function layoutInitializer(layoutEntries){
	   return function initializeScripts(){
		  var currentScript = layoutEntries.shift();
		  if(!currentScript){
			  return;
		  }
		  var fileName = currentScript.file;
		  var script = document.createElement('script');
		  script.src = './' + fileName + '.js';
		  script.type = 'text/javascript';
		  script.id = fileName;
		  console.log('Loading file', script.src);
		  
		  script.onload = function (){
			 initializeScripts();
		  };
		  if(currentScript.css){
			 var css = document.createElement('link');  
			 css.rel = 'stylesheet';
			 css.type = 'text/css';
			 css.href = './' + fileName + '.css';
			 document.body.appendChild(css);
		  }
		  document.body.appendChild(script);
	   return initializeScripts;
	  };	
	};
	
	layoutInitializer(layout)();

	window.onload = function() {
	  console.log('Starting application');
	  var domContainer = document.querySelector('#application');
	  var registerBundleApi = bundleRegister();
	  var createHeader = registerBundleApi.get('./bootstrap/header.js');
	  var createFooter = registerBundleApi.get('./bootstrap/footer.js');
	  
	  var mainApp = React.createElement('div',{
	  }, createHeader({
		  title: 'Bundle application'
	  }),
	  domApi.Router({ routes: routes, bundleRegister: registerBundleApi }),
	  createFooter({
		title: 'This is the footer of the application'
	  }));
	  ReactDOM.render(mainApp, domContainer);
	};
	
})();

