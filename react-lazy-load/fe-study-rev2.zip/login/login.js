bundleRegister().set('./login/login.js', function(){
    return React.createElement('h2', { className: 'Login'}, "This is a H2 loaded from login file");
});